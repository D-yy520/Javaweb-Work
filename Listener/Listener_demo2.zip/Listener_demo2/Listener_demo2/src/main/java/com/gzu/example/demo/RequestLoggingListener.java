package com.gzu.example.demo;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.util.Date;

@WebListener("/test")
public class RequestLoggingListener implements ServletRequestListener {

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 记录请求开始时间
        long startTime = System.currentTimeMillis();
        request.setAttribute("startTime", startTime);

        // 记录请求信息
        StringBuilder logMessage = new StringBuilder();
        logMessage.append("Request Time: ").append(new Date()).append("\n");
        logMessage.append("Client IP: ").append(request.getRemoteAddr()).append("\n");
        logMessage.append("Request Method: ").append(request.getMethod()).append("\n");
        logMessage.append("Request URI: ").append(request.getRequestURI()).append("\n");
        logMessage.append("Query String: ").append(request.getQueryString()).append("\n");
        logMessage.append("User-Agent: ").append(request.getHeader("User-Agent")).append("\n");

        // 将日志信息存储在请求属性中以便后续处理
        request.setAttribute("logMessage", logMessage.toString());

        System.out.println("Request Initialized:\n" + logMessage.toString());
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 获取开始时间
        long startTime = (Long) request.getAttribute("startTime");
        long endTime = System.currentTimeMillis();

        // 计算请求处理时间
        long processingTime = endTime - startTime;

        // 获取之前存储的日志信息
        String logMessage = (String) request.getAttribute("logMessage");

        // 添加处理时间到日志信息
        logMessage += "Request Processing Time: " + processingTime + "ms\n";

        System.out.println("Request Destroyed:\n" + logMessage);
    }
}