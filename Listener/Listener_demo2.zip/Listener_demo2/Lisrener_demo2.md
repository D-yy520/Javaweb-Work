#  Listener 功能介绍

## 概述

本示例包含两个关键的 Java 组件：一个 Servlet (`TestServlet`) 和一个请求监听器 (`RequestLoggingListener`)。这两个组件共同工作，以展示如何处理 HTTP 请求并记录相关的日志信息。

## TestServlet 功能

### 功能描述

`TestServlet` 是一个继承自 `HttpServlet` 的类，用于处理对 `/test` 路径的 GET 和 POST 请求。当接收到这些请求时，它会模拟一些处理时间（500毫秒），然后向客户端响应 "Test Servlet Executed" 的消息。

### 代码关键部分

- **@WebServlet("/test")**：注解用于声明这个 Servlet 将处理 `/test` 路径的请求。
- **doGet 和 doPost 方法**：这两个方法分别处理 GET 和 POST 请求。在本例中，doPost 方法通过调用 doGet 方法来处理 POST 请求，实现了两者的逻辑统一。
- **Thread.sleep(500)**：模拟处理时间，以毫秒为单位。

## RequestLoggingListener 功能

### 功能描述

`RequestLoggingListener` 是一个实现了 `ServletRequestListener` 接口的类，用于监听 HTTP 请求的初始化和销毁事件。它记录请求的开始时间、请求信息（如客户端 IP、请求方法、请求 URI、查询字符串和用户代理），并在请求处理完成后记录请求的处理时间。

### 代码关键部分

- **@WebListener("/test")**：注解用于声明这个监听器将监听 `/test` 路径的请求事件。但需要注意的是，`@WebListener` 的路径参数在 Servlet 3.0 规范中通常不指定具体的 URL 模式，而是监听所有请求。这里的 `/test` 可能是示例代码的一个误导，实际使用中应去掉或确认其适用性。
- **requestInitialized 方法**：在请求初始化时调用，记录请求的开始时间和相关信息，并将这些信息存储在请求属性中。
- **requestDestroyed 方法**：在请求处理完成后调用，计算请求的处理时间，并将处理时间添加到日志信息中，然后打印出来。

这两个组件共同工作，实现了对 HTTP 请求的基本处理和详细的日志记录，实现一个 ServletRequestListener 来记录每个 HTTP 请求的详细信息。

## 运行图片

![1728831420862](images/Lisrener_demo2/1728831420862.png)![1728831426999](images/Lisrener_demo2/1728831426999.png)

