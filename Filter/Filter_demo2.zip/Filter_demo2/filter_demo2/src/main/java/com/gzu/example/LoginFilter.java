package com.gzu.example;

// 导入必要的Servlet和Filter相关的类
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


// 使用@WebFilter注解定义一个过滤器，名为"LoginFilter"，并指定它应用于所有URL模式（"/*"）
@WebFilter(filterName = "LoginFilter", urlPatterns = "/*")
public class LoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        // 定义不需要登录即可访问的URL片段数组
        String[] urls = {"public", "login"};
        // 将ServletRequest和ServletResponse转换为HttpServletRequest和HttpServletResponse
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        boolean isPass = false;
        for (String url : urls) {
            if (request.getRequestURI().contains(url)) {
                isPass = true;
                break;
            }
        }
        // 如果请求通过检查（即不需要登录即可访问），则继续处理请求链
        if (isPass) {
            filterChain.doFilter(request, response);
        }else {
            HttpSession session = request.getSession();
            String username = (String) session.getAttribute("username");
            if (username != null) {
                filterChain.doFilter(request, response);
            }else {
                // 如果用户未登录，则重定向到登录页面
                response.sendRedirect("login.html");
            }
        }
    }
}
