package com.gzu.example;



import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;


// 使用@WebServlet注解来声明这个Servlet，并指定它的名称和URL映射
@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }
    // doGet()方法是处理HTTP GET请求的方法
    // 当客户端发送一个GET请求到"/hello-servlet"时，此方法会被调用
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        // Hello
        response.sendRedirect("welcome.html");
    }

    public void destroy() {
    }
}