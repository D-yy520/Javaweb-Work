package com.gzu.example;

// 导入必要的Servlet和HTTP相关的类
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

// 使用@WebServlet注解来声明这个Servlet的URL映射
// 当访问/login这个URL时，将会调用这个Servlet

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从请求中获取用户名和密码参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        // 检查用户名和密码是否正确
        // 这里简单地使用硬编码的字符串进行比较
        // 在实际应用中，应该从数据库中验证用户信息

        if ("admin".equals(username) && "123".equals(password)) {
            // 如果验证成功，将用户名存储到会话中
            // 这样可以在用户浏览其他页面时保持登录状态
            req.getSession().setAttribute("username", username);
            // 重定向到欢迎页面
            // 这里假设有一个名为welcome.html的静态页面
            resp.sendRedirect("welcome.html");
        }else {
            // 如果验证失败，重定向回登录页面
            // 这里假设有一个名为login.html的登录表单页面
            resp.sendRedirect("login.html");
        }
    }
}
